<?php
class Symbic_Form_Decorator_ContentPane extends Zend_Dojo_Form_Decorator_ContentPane
{
}