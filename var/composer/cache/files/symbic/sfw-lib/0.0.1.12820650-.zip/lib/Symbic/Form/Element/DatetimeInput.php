<?php
class Symbic_Form_Element_DatetimeInput extends Symbic_Form_Element_AbstractInput
{
	public $type = 'datetime';
}