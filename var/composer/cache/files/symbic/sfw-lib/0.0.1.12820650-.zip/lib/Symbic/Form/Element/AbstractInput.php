<?php
abstract class Symbic_Form_Element_AbstractInput extends Symbic_Form_Element_AbstractElement
{
    public $helper		= 'formInput';
}