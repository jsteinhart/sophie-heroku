<?php
abstract class Symbic_Form_SubForm_AbstractSubForm extends Symbic_Form_AbstractForm
{
	protected $_isSubForm = true;
}