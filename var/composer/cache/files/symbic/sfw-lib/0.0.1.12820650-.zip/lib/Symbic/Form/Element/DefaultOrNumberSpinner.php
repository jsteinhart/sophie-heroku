<?php
class Symbic_Form_Element_DefaultOrNumberSpinner extends Symbic_Form_Element_DefaultOrTextInput
{
	public $helper = 'formDefaultOrNumberSpinner';
}