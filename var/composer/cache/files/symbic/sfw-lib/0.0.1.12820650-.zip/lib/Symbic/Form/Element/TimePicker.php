<?php
class Symbic_Form_Element_TimePicker extends Symbic_Form_Element_AbstractElement
{
	public $helper	= 'formTimePicker';
}