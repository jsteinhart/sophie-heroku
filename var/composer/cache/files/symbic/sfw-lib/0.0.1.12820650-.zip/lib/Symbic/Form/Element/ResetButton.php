<?php
class Symbic_Form_Element_ResetButton extends Symbic_Form_Element_Button
{
    public $helper		= 'formButton';
	public $type		= 'reset';
}