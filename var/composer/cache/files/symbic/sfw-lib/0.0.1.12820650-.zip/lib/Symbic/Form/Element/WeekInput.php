<?php
class Symbic_Form_Element_WeekInput extends Symbic_Form_Element_TextInput
{
	public $type	= 'week';
}