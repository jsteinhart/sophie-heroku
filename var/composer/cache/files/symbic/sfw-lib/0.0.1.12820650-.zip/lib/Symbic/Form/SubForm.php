<?php
class Symbic_Form_SubForm extends Symbic_Form
{
	protected $_isSubForm = true;
}