<?php
class Symbic_View_Helper_Container_HeadScript extends Symbic_View_Helper_Container_AbstractContainer
{
}