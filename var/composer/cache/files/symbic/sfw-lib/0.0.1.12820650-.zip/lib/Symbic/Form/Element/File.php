<?php
class Symbic_Form_Element_File extends Symbic_Form_Element_FileInput
{
}