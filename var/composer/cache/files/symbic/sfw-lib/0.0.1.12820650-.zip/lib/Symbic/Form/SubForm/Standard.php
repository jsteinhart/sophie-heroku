<?php
class Symbic_Form_SubForm_Standard extends Symbic_Form_Standard
{
	protected $_isSubForm = true;
}