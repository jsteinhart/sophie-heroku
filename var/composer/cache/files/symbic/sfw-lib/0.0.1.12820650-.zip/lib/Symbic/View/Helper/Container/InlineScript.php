<?php
class Symbic_View_Helper_Container_InlineScript extends Symbic_View_Helper_Container_AbstractContainer
{
}