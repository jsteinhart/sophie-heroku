<?php
class Symbic_View_Loader_Filter extends Symbic_Loader_AliasMap
{
	protected $_filter = 'ucfirst';

	protected $_map = array(
	);
}