<?php
class Symbic_Form_DisplayGroup_Standard extends Symbic_Form_DisplayGroup_AbstractDisplayGroup
{
}