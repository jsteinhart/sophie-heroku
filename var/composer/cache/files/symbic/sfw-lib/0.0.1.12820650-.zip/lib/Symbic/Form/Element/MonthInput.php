<?php
class Symbic_Form_Element_MonthInput extends Symbic_Form_Element_TextInput
{
	public $type	= 'month';
}