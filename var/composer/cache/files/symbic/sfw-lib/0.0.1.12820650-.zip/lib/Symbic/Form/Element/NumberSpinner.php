<?php
class Symbic_Form_Element_NumberSpinner extends Symbic_Form_Element_AbstractNumberInput
{
	public $type		= 'number';
	public $helper		= 'formNumberSpinner'; 
}