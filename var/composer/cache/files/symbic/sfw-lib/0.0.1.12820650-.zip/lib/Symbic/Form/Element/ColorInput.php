<?php
class Symbic_Form_Element_ColorInput extends Symbic_Form_Element_AbstractInput
{
	public $type = 'color';
}