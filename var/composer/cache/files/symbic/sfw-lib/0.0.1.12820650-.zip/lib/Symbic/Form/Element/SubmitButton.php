<?php
class Symbic_Form_Element_SubmitButton extends Symbic_Form_Element_Button
{
    public $helper		= 'formButton';
	public $type		= 'submit';
}