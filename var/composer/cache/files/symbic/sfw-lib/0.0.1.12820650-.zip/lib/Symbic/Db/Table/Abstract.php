<?php
// TODO: eliminate this in favor of Symbic_Db_Table_AbstractTable
class Symbic_Db_Table_Abstract extends Symbic_Db_Table_AbstractTable
{
}