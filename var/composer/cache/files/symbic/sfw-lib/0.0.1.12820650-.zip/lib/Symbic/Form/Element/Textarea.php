<?php
class Symbic_Form_Element_Textarea extends Symbic_Form_Element_AbstractInput
{
    public $rows		= 24;
    public $cols		= 80;
    public $helper		= 'formTextarea';
}