<?php
class Symbic_Form_Element_DateRangePicker extends Symbic_Form_Element_AbstractElement
{
	public $helper = 'formDateRangePicker';
}