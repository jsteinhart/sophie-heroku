<?php
class Symbic_Form_Element_Multiselect extends Symbic_Form_Element_Select
{
    public $multiple		= 'multiple';
    protected $_isArray		= true;
}