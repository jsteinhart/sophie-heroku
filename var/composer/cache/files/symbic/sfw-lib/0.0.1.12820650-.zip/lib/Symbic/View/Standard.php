<?php
class Symbic_View_Standard extends Symbic_View_AbstractView
{
	protected $_defaultHelperLoader			= 'Symbic_View_Loader_Helper';
	protected $_defaultFilterLoader			= 'Symbic_View_Loader_Filter';
}