<?php
class Symbic_Form_Element_RangeInput extends Symbic_Form_Element_TextInput
{
	public $type		= 'range';
}