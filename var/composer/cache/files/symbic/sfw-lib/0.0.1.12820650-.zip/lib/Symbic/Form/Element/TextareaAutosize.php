<?php
class Symbic_Form_Element_TextareaAutosize extends Symbic_Form_Element_Textarea
{
	public $rows		= 1;
    public $helper		= 'formTextareaAutosize';
}