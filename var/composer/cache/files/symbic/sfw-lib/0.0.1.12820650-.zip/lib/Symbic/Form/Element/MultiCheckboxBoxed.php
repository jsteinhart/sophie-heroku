<?php
class Symbic_Form_Element_MultiCheckboxBoxed extends Symbic_Form_Element_MultiCheckbox
{
	public $helper		= 'formMultiCheckboxBoxed';
}