<?php

/**
 * Deprectated in favor of Symbic_Task_AbstractTask
 */
abstract class Symbic_Task_Abstract extends Symbic_Task_AbstractTask
{
}