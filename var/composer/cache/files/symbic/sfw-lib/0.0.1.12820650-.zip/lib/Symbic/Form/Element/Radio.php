<?php
class Symbic_Form_Element_Radio extends Symbic_Form_Element_AbstractMulti
{
    public $helper		= 'formRadio';
}