<?php
class Symbic_Form_Element_CheckboxInlineLabel extends Symbic_Form_Element_Checkbox
{
    public $helper = 'formCheckboxInlineLabel';
}
