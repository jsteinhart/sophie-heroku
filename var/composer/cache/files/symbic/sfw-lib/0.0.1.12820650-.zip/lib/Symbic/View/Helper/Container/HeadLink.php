<?php
class Symbic_View_Helper_Container_HeadLink extends Symbic_View_Helper_Container_AbstractContainer
{
}