<?php
class Symbic_Form_Element_EmailInput extends Symbic_Form_Element_TextInput
{
	public $type = 'email';
}