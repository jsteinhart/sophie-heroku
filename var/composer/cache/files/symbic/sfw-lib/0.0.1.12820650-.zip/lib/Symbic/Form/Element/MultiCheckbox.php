<?php
class Symbic_Form_Element_MultiCheckbox extends Symbic_Form_Element_AbstractMulti
{
    public $helper			= 'formMultiCheckbox';
    protected $_isArray		= true;
}