<?php
class Symbic_Form_Element_ComboBox extends Symbic_Form_Element_AbstractMulti
{
	public $type	= 'text';
    public $helper	= 'formComboBox';
}