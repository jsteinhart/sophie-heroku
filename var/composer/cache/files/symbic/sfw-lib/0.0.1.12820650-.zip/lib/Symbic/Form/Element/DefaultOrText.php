<?php
// TODO: replace this in favor of Symbic_Form_Element_DefaultOrTextInput
class Symbic_Form_Element_DefaultOrText extends Symbic_Form_Element_DefaultOrTextInput
{
}