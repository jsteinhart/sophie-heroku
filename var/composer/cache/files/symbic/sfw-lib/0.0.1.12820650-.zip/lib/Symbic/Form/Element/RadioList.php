<?php
class Symbic_Form_Element_RadioList extends Symbic_Form_Element_Radio
{
	public $helper		= 'formRadioList';
}