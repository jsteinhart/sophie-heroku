<?php
class Symbic_Dojo_Form_SubForm extends Symbic_Dojo_Form
{
	protected $_isSubForm = true;
}