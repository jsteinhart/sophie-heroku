<?php
class Symbic_Form_Element_DatetimeLocalInput extends Symbic_Form_Element_AbstractInput
{
	public $type = 'datetime-local';
}