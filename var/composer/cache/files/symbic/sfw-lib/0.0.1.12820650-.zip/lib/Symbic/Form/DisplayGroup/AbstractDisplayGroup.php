<?php
class Symbic_Form_DisplayGroup_AbstractDisplayGroup extends Zend_Form_DisplayGroup
{
}