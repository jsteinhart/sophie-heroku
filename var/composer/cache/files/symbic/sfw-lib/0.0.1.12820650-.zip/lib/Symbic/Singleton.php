<?php
// TODO: eliminate this in favor for Symbic_Base_AbstractSingleton
abstract class Symbic_Singleton extends \Symbic_Base_AbstractSingleton
{
}