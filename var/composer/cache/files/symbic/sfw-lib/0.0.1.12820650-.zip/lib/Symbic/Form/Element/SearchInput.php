<?php
class Symbic_Form_Element_SearchInput extends Symbic_Form_Element_TextInput
{
	public $type		= 'search';
}