<?php
class Symbic_Form_Element_Select extends Symbic_Form_Element_AbstractMulti
{
	public $helper = 'formSelect';
}