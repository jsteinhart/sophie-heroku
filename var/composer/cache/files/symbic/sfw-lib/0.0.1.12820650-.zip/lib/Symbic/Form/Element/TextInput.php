<?php
class Symbic_Form_Element_TextInput extends Symbic_Form_Element_AbstractInput
{
	public $type	= 'text';
}