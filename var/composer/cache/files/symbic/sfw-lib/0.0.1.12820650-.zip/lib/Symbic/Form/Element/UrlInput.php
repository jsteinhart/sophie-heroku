<?php
class Symbic_Form_Element_UrlInput extends Symbic_Form_Element_TextInput
{
	public $type	= 'url';
}