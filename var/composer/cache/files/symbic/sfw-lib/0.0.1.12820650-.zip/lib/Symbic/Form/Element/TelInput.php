<?php
class Symbic_Form_Element_TelInput extends Symbic_Form_Element_TextInput
{
	public $helper		= 'formTelInput';
    public $type		= 'tel';
}