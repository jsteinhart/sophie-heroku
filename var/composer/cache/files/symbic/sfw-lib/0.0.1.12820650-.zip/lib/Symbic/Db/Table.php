<?php
class Symbic_Db_Table extends Symbic_Db_Table_AbstractTable
{
}