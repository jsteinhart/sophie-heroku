<?php
class Symbic_Form_Element_FileInput extends Zend_Form_Element_File
{
}