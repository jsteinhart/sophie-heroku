<?php

/**
 *
 */
class Symbic_Module_Standard extends Symbic_Module_AbstractModule
{
}