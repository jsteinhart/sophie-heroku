<?php
class Symbic_Form_Element_Hidden extends Symbic_Form_Element_AbstractElement
{
    public $helper		= 'formHidden';
}