<?php
class ControllersTest extends Symbic_Controller_Test_AbstractControllersTest {
}