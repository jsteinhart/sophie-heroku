<?php


return array(
	'generateEmptyComponentsLicense' => false,
	);