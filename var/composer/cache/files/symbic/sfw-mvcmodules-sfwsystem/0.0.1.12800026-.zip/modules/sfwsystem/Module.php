<?php
class Sfwsystem_Module extends \Symbic_Module_Standard
{
}