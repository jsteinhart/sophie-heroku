<?php
class Sfwdefault_Module extends \Symbic_Module_Standard
{
}