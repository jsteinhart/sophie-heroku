<?php
class Sfwdefault_SfwmoduleassetController extends Symbic_Controller_Module_Asset {
}