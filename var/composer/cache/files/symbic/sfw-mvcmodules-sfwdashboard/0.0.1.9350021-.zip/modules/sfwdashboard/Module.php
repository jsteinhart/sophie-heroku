<?php
class Sfwdashboard_Module extends \Symbic_Module_Standard
{
}