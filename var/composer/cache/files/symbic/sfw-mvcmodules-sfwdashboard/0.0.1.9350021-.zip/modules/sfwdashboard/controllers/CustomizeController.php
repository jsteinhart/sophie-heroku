<?php
class Sfwdashboard_IndexController extends Symbic_Controller_Action
{
	// TODO: implement an interface to let users customize their dashboard contents
	public function indexAction()
	{
	}
}