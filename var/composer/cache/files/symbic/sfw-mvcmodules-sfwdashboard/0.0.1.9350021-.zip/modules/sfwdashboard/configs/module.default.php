<?php
return array(
	'headline' => 'Welcome!'
);