<?php
namespace Sfwuserprofile\Model;

class User extends \Symbic_Db_Table_Abstract
{

	public $_name	 = 'system_user';
	public $_primary = 'id';

}
