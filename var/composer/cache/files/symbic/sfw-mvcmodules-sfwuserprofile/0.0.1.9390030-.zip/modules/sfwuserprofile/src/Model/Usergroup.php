<?php
namespace Sfwuserprofile\Model;

class Usergroup extends \Symbic_Db_Table_Abstract
{
	public $_name = 'system_usergroup';
	public $_primary = 'id';
}