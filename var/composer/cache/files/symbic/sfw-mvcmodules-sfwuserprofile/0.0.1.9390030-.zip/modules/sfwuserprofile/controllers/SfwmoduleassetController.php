<?php
class Sfwuserprofile_SfwmoduleassetController extends Symbic_Controller_Module_Asset {
}