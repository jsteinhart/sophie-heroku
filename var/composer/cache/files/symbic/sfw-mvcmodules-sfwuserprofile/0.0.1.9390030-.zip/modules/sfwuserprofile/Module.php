<?php
class Sfwuserprofile_Module extends \Symbic_Module_Standard
{
}