(function( window, $, undefined)
{
	var module,
		baseUrl = '/';
	
	module =
	{
	};

	module.routes = {
	};

	window.sfwuserprofile = module;
	
}) ( window, window.jQuery);