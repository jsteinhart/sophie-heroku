<?php
class Sfwinstaller_Module extends \Symbic_Module_Standard
{
}