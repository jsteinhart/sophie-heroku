<?php
namespace Sfwsysadmin\Model;

class Task extends \Symbic_Singleton
{
}