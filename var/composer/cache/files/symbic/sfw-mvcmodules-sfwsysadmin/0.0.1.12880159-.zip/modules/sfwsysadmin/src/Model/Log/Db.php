<?php
namespace Sfwsysadmin\Model\Log;

class Db extends \Symbic_Singleton
{
}