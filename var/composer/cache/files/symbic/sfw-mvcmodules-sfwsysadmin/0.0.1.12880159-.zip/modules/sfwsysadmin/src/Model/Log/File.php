<?php
namespace Sfwsysadmin\Model\Log;

class File  extends \Symbic_Singleton
{
}