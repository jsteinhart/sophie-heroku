<?php
namespace Sfwsysadmin\Model\User;

class Table extends \Symbic_Db_Table_Abstract
{
	public $_name = 'system_user';
	public $_primary = 'id';
}