<?php
namespace Sfwsysadmin\Model\Usergroup;

class Table extends \Symbic_Db_Table_Abstract
{
	public $_name = 'system_usergroup';
	public $_primary = 'id';
}