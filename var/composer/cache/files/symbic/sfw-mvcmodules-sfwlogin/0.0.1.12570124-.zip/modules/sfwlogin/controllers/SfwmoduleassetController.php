<?php
class Sfwlogin_SfwmoduleassetController extends Symbic_Controller_Module_Asset {
}