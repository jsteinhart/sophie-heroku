<?php
class Sfwlogin_Module extends \Symbic_Module_Standard
{
}