<?php

class NestedPartials
{
    public $val = 'FOURTH!';
}
