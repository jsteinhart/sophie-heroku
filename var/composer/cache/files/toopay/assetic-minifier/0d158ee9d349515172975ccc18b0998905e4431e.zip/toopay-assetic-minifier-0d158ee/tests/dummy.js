/* Some Comment */
function foo() {
	// Another comment
	return"bar"; // Some weird comment
}