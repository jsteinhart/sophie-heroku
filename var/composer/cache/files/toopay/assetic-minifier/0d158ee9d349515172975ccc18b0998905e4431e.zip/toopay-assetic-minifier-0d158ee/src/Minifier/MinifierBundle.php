<?php
namespace Minifier;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MinifierBundle extends Bundle
{
} 