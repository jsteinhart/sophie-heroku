<?php

class PHPParser_Node_Expr_Cast_Object extends PHPParser_Node_Expr_Cast
{
}